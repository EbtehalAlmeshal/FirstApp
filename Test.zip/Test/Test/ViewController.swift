//
//  ViewController.swift
//  Test
//
//  Created by ابتهال عبدالعزيز on 16/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBOutlet weak var NameText: UITextField!
    
    @IBOutlet weak var JobText: UITextField!
    
    @IBAction func ShowMassegeButton(_ sender: Any) {
        MSBox.show(text: "helo : \(NameText.text!) و الوظيفه \(JobText.text!)", complation: nil, Nocomplation: nil)
         
    }
    
    
    
    
    
    
}

